import json

def build_response(code, **kwargs):

    return {
        "statusCode": code,
        "body": json.dumps(kwargs)
    }

def check_200(response):
    return response['ResponseMetadata']['HTTPStatusCode'] == 200