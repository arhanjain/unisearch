import json
import time
# import bcrypt
import account
import asyncio

async def async_handler(event, context):
    pass

def lambda_handler(event, context):
    # loop = asyncio.get_event_loop()

    res = None
    match event['path']:
        case '/health':
            pass
        case '/register':
            res = account.register(event["username"], event["password"])
        case '/login':
            res = account.login(event["username"], event["password"])
        case _:
            res ={
                'statusCode': 200,
                'body': json.dumps('Hello from Lambda!')
            }


    return res 

if __name__ == '__main__':
    event = {
        'path': '/login',
        'username': "pillujain02",
        'password': "dog"
    }

    r = lambda_handler(event, None)
    print(r)